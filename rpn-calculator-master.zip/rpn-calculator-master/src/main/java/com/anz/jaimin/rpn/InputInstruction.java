package com.anz.jaimin.rpn;

import com.anz.jaimin.rpn.common.InputOperator;
import com.anz.jaimin.rpn.exception.EvaluatorException;

public class InputInstruction {
    InputOperator operator;
    Double value;

    public InputInstruction(InputOperator operator, Double value) {
        this.operator = operator;
        this.value = value;
}

    public String getReverseInstruction() throws EvaluatorException {
        if (operator.getMinimumOperands() < 1)
            throw new EvaluatorException(String.format("invalid operation for operator %s", operator.getAirthmeticOperator()));

        return (operator.getMinimumOperands() < 2) ?
                String.format("%s", operator.getArithmeticOperatorOpp()) :
                String.format("%f %s %f", value, operator.getArithmeticOperatorOpp(), value);
    }
}
