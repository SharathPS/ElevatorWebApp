package com.anz.jaimin.rpn.common;

import com.anz.jaimin.rpn.exception.EvaluatorException;

import java.util.HashMap;
import java.util.Map;

import static java.lang.Math.pow;
import static java.lang.Math.sqrt;

public enum InputOperator {

    ADDITION("+", "-", 2) {
        public Double calculate(Double firstOperand, Double secondOperand) {
            return secondOperand + firstOperand;
        }
    },

    SUBTRACTION("-", "+", 2) {
        public Double calculate(Double firstOperand, Double secondOperand) {
            return secondOperand - firstOperand;
        }
    },

    MULTIPLICATION("*", "/", 2) {
        public Double calculate(Double firstOperand, Double secondOperand) {
            return secondOperand * firstOperand;
        }
    },

    DIVISION("/", "*", 2) {
        public Double calculate(Double firstOperand, Double secondOperand) throws EvaluatorException {
            if (firstOperand == 0)
                throw new EvaluatorException("Cannot divide by 0.");
            return secondOperand / firstOperand;
        }
    },

    SQUAREROOT("sqrt", "pow", 1) {
        public Double calculate(Double firstOperand, Double secondOperand) {
            return sqrt(firstOperand);
        }
    },

    POWER("pow", "sqrt", 1) {
        public Double calculate(Double firstOperand, Double secondOperand) {
            return pow(firstOperand, 2.0);
        }
    },

    UNDO("undo", null, 0) {
        public Double calculate(Double firstOperand, Double secondOperand) throws EvaluatorException {
            throw new EvaluatorException("Invalid operation");
        }
    },

    CLEAR("clear", null, 0) {
        public Double calculate(Double firstOperand, Double secondOperand) throws EvaluatorException {
            throw new EvaluatorException("Invalid operation");
        }
    };

    // using map for a constant lookup cost
    private static final Map<String, InputOperator> lookup = new HashMap<String, InputOperator>();

    static {
        for (InputOperator o : values()) {
            lookup.put(o.getAirthmeticOperator(), o);
        }
    }

    private String arithmeticOperator;
    private String arithmeticOperatorOpp;
    private int minimumOperands;

    InputOperator(String airthmeticOperator, String arithmeticOperatorOpp, int minimumOperands) {
        this.arithmeticOperator = airthmeticOperator;
        this.arithmeticOperatorOpp = arithmeticOperatorOpp;
        this.minimumOperands = minimumOperands;
    }

    public static InputOperator getEnum(String value) {
        return lookup.get(value);
    }

    public abstract Double calculate(Double firstOperand, Double secondOperand) throws EvaluatorException;

    public String getAirthmeticOperator() {
        return arithmeticOperator;
    }

    public String getArithmeticOperatorOpp() {
        return arithmeticOperatorOpp;
    }

    public int getMinimumOperands() {
        return minimumOperands;
    }

    @Override
    public String toString() {
        return arithmeticOperator;
    }
}