import com.anz.jaimin.rpn.exception.EvaluatorException;
import com.anz.jaimin.rpn.common.InputOperator;
import org.junit.Test;

import java.util.Random;

import static java.lang.Math.pow;
import static java.lang.Math.sqrt;
import static org.junit.Assert.assertEquals;

public class OperatorTest {

    @Test
    public void testCalculate() throws EvaluatorException {
        Random r = new Random();
        double firstOperand = r.nextDouble();
        double secondOperand = r.nextDouble();
        assertEquals(secondOperand + firstOperand, InputOperator.ADDITION.calculate(firstOperand, secondOperand), 0);
        assertEquals(secondOperand - firstOperand, InputOperator.SUBTRACTION.calculate(firstOperand, secondOperand), 0);
        assertEquals(secondOperand * firstOperand, InputOperator.MULTIPLICATION.calculate(firstOperand, secondOperand), 0);
        assertEquals(secondOperand / firstOperand, InputOperator.DIVISION.calculate(firstOperand, secondOperand), 0);
        assertEquals(pow(firstOperand, 2.0), InputOperator.POWER.calculate(firstOperand, null), 0);
        assertEquals(sqrt(secondOperand), InputOperator.SQUAREROOT.calculate(secondOperand, null), 0);
    }

    @Test(expected = EvaluatorException.class)
    public void testDivideByZero() throws EvaluatorException {
        InputOperator.DIVISION.calculate(0.0, 0.0);
    }

    @Test(expected = EvaluatorException.class)
    public void testInvalidOperations() throws EvaluatorException {
        InputOperator.UNDO.calculate(0.0, 0.0);
        InputOperator.CLEAR.calculate(0.0, 0.0);
    }
}
