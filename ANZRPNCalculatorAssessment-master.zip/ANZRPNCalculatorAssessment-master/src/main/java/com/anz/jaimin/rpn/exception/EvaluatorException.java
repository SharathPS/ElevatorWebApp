package com.anz.jaimin.rpn.exception;

public class EvaluatorException extends Exception {
    public EvaluatorException(String message) {
        super(message);
    }
}
